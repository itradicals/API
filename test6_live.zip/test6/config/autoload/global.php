<?php
return array(
    'db' => array(
        'adapters' => array(
            'db\\msg' => array(),
        ),
    ),
    'router' => array(
        'routes' => array(
            'oauth' => array(
                'options' => array(
                    'route' => '/oauth',
                ),
            ),
        ),
    ),
    'zf-mvc-auth' => array(
        'authentication' => array(),
    ),
);
