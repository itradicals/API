<?php
return array(
    'db' => array(
        'adapters' => array(
            'db\\msg' => array(
                'driver' => 'Pdo_Sqlite',
                'database' => '/home2/itradica/public_html/jd/test6/data/messages.sqlite',
            ),
        ),
    ),
    'zf-oauth2' => array(
        'storage' => 'ZF\\OAuth2\\Adapter\\PdoAdapter',
        'db' => array(
            'dsn_type' => 'PDO',
            'dsn' => 'sqlite:vendor/zfcampus/zf-oauth2/data/dbtest.sqlite',
            'username' => null,
            'password' => null,
        ),
    ),
    'zf-mvc-auth' => array(
        'authentication' => array(),
    ),
);
