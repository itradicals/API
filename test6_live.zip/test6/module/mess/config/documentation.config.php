<?php
return array(
    'mess\\V1\\Rest\\Message\\Controller' => array(
        'collection' => array(
            'GET' => array(
                'description' => '<p>To get a collection from API user can use GET method of the API.</p>
<p>Require : OAuth2 Access Token</p>
<p>Steps to get Access Token:</p>
<h4 style="color: #000000;"><span style="font-size: small;"><strong>Request URL: http://api.itradicals.com/oauth</strong></span></h4>
<p><strong>Method: POST</strong></p>
<p><strong>Request Headers</strong>:</p>
<blockquote>
<p style="color: #114df7;">{<br />&nbsp; &nbsp; "Accept": "application/json",</p>
<p style="color: #114df7;">&nbsp; &nbsp; "Content-Type": "application/json"</p>
<p style="color: #114df7;">}</p>
</blockquote>
<p><strong>Post Data:</strong></p>
<blockquote>
<p style="color: #114df7;">{</p>
<p style="color: #114df7;">&nbsp; &nbsp;"username": "testuser",</p>
<p style="color: #114df7;">&nbsp; &nbsp;"password": "testpass",</p>
<p style="color: #114df7;">&nbsp; &nbsp;"grant_type":"password",</p>
<p style="color: #114df7;">&nbsp; &nbsp;"client_id": "testclient2"</p>
<p style="color: #114df7;">}</p>
</blockquote>
<p><strong>OAuth2 Response (Response Header):</strong></p>
<blockquote>
<p style="color: #114df7;">{<br />&nbsp; &nbsp; "access_token": "2844e59ff3ae2c21ce2f2b500cd91f5d9f706ae9",</p>
<p style="color: #114df7;">&nbsp; &nbsp; "expires_in": 3600,</p>
<p style="color: #114df7;">&nbsp; &nbsp; "token_type": "Bearer",&nbsp;</p>
<p style="color: #114df7;">&nbsp; &nbsp; "scope": null,</p>
<p style="color: #114df7;">&nbsp; &nbsp; "refresh_token": "bf60a0c017af71a13ced2df80ea287931ed1d261"<br />}</p>
</blockquote>
<p style="color: #114df7;">&nbsp;</p>
<p style="color: #000000;"><span style="font-size: small;" data-mce-mark="1"><strong>Request messages API</strong></span></p>
<h2 style="color: #000000;"><span style="font-size: small;" data-mce-mark="1"><strong>Request URL: http://api.itradicals.com/message</strong></span></h2>
<h2 style="color: #000000;"><span style="font-size: small;" data-mce-mark="1"><strong>Method: GET</strong></span></h2>
<p style="color: #000000;">&nbsp;</p>
<p><span style="font-size: small;" data-mce-mark="1"><strong>Request Headers</strong>:</span></p>
<p><span style="font-size: x-small; color: #114df7;" data-mce-mark="1">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {</span></p>
<blockquote>
<p style="color: #114df7;">&nbsp; &nbsp; "Accept": "application/json",</p>
<p style="color: #114df7;">&nbsp; &nbsp; "Authorization": "Bearer 2844e59ff3ae2c21ce2f2b500cd91f5d9f706ae9"</p>
<p style="color: #114df7;">}</p>
</blockquote>
<h2><span style="font-size: small;"><strong>Response Body</strong></span></h2>
<blockquote>
<p style="color: #114df7;">{<br />&nbsp; "_links": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; "self": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp;"href": "http://api.itradicals.com/message?page=1"</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp;},</p>
<p style="color: #114df7;">&nbsp; &nbsp; "first": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp;"href": "http://api.itradicals.com/message"</p>
<p style="color: #114df7;">&nbsp; &nbsp; },</p>
<p style="color: #114df7;">&nbsp; &nbsp;"last": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; "href": "http://api.itradicals.com/message?page=1"</p>
<p style="color: #114df7;">&nbsp; &nbsp;}</p>
<p style="color: #114df7;">},</p>
<p style="color: #114df7;">"_embedded": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; "message": [</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp;{</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"id": "1",</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"message": "hello world",</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"username": "user1",</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"created_at": "2014-06-20 04:47:48",</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"_links": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"self": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"href": "http://api.itradicals.com/message/1"</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;}</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp;}</p>
<p style="color: #114df7;">&nbsp; &nbsp; },</p>
<p style="color: #114df7;">&nbsp; &nbsp;{</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp;"id": "2",</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp;"message": "hello world again",</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp;"username": "user2",</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp;"created_at": "2014-06-20 05:18:59",</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp;"_links": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"self": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;"href": "http://api.itradicals.com/message/2"</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;}</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp;}</p>
<p style="color: #114df7;">&nbsp; &nbsp;}<br /> ]</p>
<p style="color: #114df7;">},</p>
<p style="color: #114df7;">"page_count": 1,</p>
<p style="color: #114df7;">"page_size": 25,</p>
<p style="color: #114df7;">"total_items": 2</p>
<p style="color: #114df7;">}</p>
</blockquote>
<p style="color: #000000;">&nbsp;</p>',
                'request' => null,
                'response' => '{
   "_links": {
       "self": {
           "href": "/message"
       },
       "first": {
           "href": "/message?page={page}"
       },
       "prev": {
           "href": "/message?page={page}"
       },
       "next": {
           "href": "/message?page={page}"
       },
       "last": {
           "href": "/message?page={page}"
       }
   }
   "_embedded": {
       "message": [
           {
               "_links": {
                   "self": {
                       "href": "/message[/:message_id]"
                   }
               }

           }
       ]
   }
}',
            ),
            'POST' => array(
                'description' => '<p><strong><span style="font-size: small;" data-mce-mark="1">Storing messages from API.</span></strong></p>
<p>&nbsp;</p>
<p><strong><span style="font-size: small;" data-mce-mark="1">Request URL: http://api.itradicals.com/message</span></strong></p>
<p><strong><span style="font-size: small;" data-mce-mark="1">Method: POST</span></strong></p>
<table style="height: 98px; width: 398px;" border="0">
<tbody>
<tr>
<td><strong>Parameter</strong></td>
<td><strong>Value</strong></td>
<td><strong>Description</strong></td>
</tr>
<tr>
<td>message</td>
<td>{Text message}</td>
<td>users message to store in database</td>
</tr>
<tr>
<td>username</td>
<td>{any name}</td>
<td>user\'s name for this message</td>
</tr>
</tbody>
</table>
<p><strong><span style="font-size: small;" data-mce-mark="1">Request Header:</span></strong></p>
<blockquote>
<p style="color: #114df7;">&nbsp;{</p>
<p style="color: #114df7;">&nbsp; &nbsp; "Accept" : "application/json",</p>
<p style="color: #114df7;">&nbsp; &nbsp; "Content-Type" : "<span data-mce-mark="1">application/json",</span></p>
<p style="color: #114df7;"><span data-mce-mark="1">&nbsp; &nbsp; "Authorization" : "Bearer 2844e59ff3ae2c21ce2f2b500cd91f5d9f706ae9"</span></p>
<p style="color: #114df7;">&nbsp;}</p>
</blockquote>
<p style="color: #000000;"><span style="font-size: small;" data-mce-mark="1"><strong>Request Body:</strong></span></p>
<blockquote>
<p style="color: #114df7;">{</p>
<p style="color: #114df7;">&nbsp; &nbsp; "message" : "hello world again",</p>
<p style="color: #114df7;">&nbsp; &nbsp; "username" : "user1"</p>
<p style="color: #114df7;">&nbsp;}</p>
</blockquote>
<p style="color: #114df7;"><span style="font-size: small;" data-mce-mark="1"><strong style="color: #000000;">Response Body:</strong></span></p>
<p style="color: #114df7;">&nbsp;</p>
<blockquote>
<p style="color: #114df7;">{<br />&nbsp; &nbsp; "id": "5",</p>
<p style="color: #114df7;">&nbsp; &nbsp; "message": "hello world again",</p>
<p style="color: #114df7;">&nbsp; &nbsp; "username": "user1",</p>
<p style="color: #114df7;">&nbsp; &nbsp; "created_at": "2014-06-26 06:42:40",</p>
<p style="color: #114df7;">&nbsp; &nbsp; "_links": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; "self": {</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; "href": "http://api.itradicals.com/message/5"</p>
<p style="color: #114df7;">&nbsp; &nbsp; &nbsp; &nbsp; }</p>
<p style="color: #114df7;">&nbsp; &nbsp; }<br />}</p>
</blockquote>
<p style="color: #114df7;">&nbsp;</p>',
                'request' => '{
"message": "hello world again",
"username": "user1"
}',
                'response' => '{
    "id": "5",
    "message": "hello world again",
    "username": "user1",
    "created_at": "2014-06-26 06:42:40",
    "_links": {
        "self": {
            "href": "http://api.itradicals.com/message/5"
        }
    }
}',
            ),
        ),
        'entity' => array(
            'GET' => array(
                'description' => null,
                'request' => null,
                'response' => null,
            ),
            'PATCH' => array(
                'description' => null,
                'request' => null,
                'response' => null,
            ),
            'PUT' => array(
                'description' => null,
                'request' => null,
                'response' => null,
            ),
            'DELETE' => array(
                'description' => null,
                'request' => null,
                'response' => null,
            ),
        ),
        'description' => 'Simple API for OAuth2 and Messages getting and storing into database.',
    ),
);
