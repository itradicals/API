<?php
require __DIR__ . '/src/mess/Module.php';