<?php
namespace mess\V1\Rest\Message;

use ArrayObject;

class MessageEntity extends ArrayObject
{
}
