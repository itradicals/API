<?php
namespace mess\V1\Rest\Message;

use Zend\Paginator\Paginator;

class MessageCollection extends Paginator
{
}
