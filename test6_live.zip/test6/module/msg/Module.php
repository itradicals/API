<?php
require __DIR__ . '/src/msg/Module.php';