<?php
return array(
    'router' => array(
        'routes' => array(),
    ),
    'zf-versioning' => array(
        'uri' => array(),
    ),
    'zf-rest' => array(),
    'zf-content-negotiation' => array(
        'controllers' => array(),
        'accept_whitelist' => array(),
        'content_type_whitelist' => array(),
    ),
    'zf-hal' => array(
        'metadata_map' => array(),
    ),
    'zf-apigility' => array(
        'db-connected' => array(),
    ),
);
